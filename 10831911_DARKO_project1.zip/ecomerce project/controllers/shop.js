const Product = require('../models/product')

exports.getIndex = async (req, res, next) => {
    const products = await Product.find().sort({ createdAt : -1 })
    res.render('shop/index', {
        pageTitle : "Products",
        products : products,
        path : '/'
    })
}

exports.getAddProduct = async (req, res, next) => {
    res.render('shop/addProduct', {
        pageTitle : 'Add product page',
        name : '',
        price : '',
        description : '',
        path : '/add-product',
        imageUrl : ''
    })
}

exports.postAddProduct = async (req, res, next ) => {
    const name = req.body.name
    const description = req.body.description
    const price = +req.body.price

    console.log({name, description, price})

    const file = req.file
    console.log(file)
    if(!file){
        return res.render('shop/addProduct', {
            pageTitle : 'Add product',
            path : '/add-product',
            name,
            description,
            price,
            imageUrl
        })
    }
    const imageUrl = file.path.replace("\\", '/')

    const product = new Product({ name : name, description : description, price : price, imageUrl : imageUrl, creator : req.session.userId})
    await product.save((error) => {
        if(error) {
            next(error)
        }
    })
    return res.redirect('/')
}