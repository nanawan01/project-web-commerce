const router = require("express").Router()
const shopController = require('../controllers/shop')
const isAuth = require('../middleware/is-auth')

router.get("/", shopController.getIndex)

router.get('/add-product', isAuth, shopController.getAddProduct)

router.post('/add-product', isAuth,shopController.postAddProduct)
module.exports = router